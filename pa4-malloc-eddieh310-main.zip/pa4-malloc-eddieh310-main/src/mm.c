#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <stdbool.h>
#include <math.h>

/* The standard allocator interface from stdlib.h.  These are the
 * functions you must implement, more information on each function is
 * found below. They are declared here in case you want to use one
 * function in the implementation of another. */
void *malloc(size_t size);
void free(void *ptr);
void *calloc(size_t nmemb, size_t size);
void *realloc(void *ptr, size_t size);

/* When requesting memory from the OS using sbrk(), request it in
 * increments of CHUNK_SIZE. */
#define CHUNK_SIZE (1<<12)

typedef struct node{
    size_t header;//size of chunk
    struct node *next;
}node;

static struct node** freelist;

/*
 * This function, defined in bulk.c, allocates a contiguous memory
 * region of at least size bytes.  It MAY NOT BE USED as the allocator
 * for pool-allocated regions.  Memory allocated using bulk_alloc()
 * must be freed by bulk_free().
 *
 * This function will return NULL on failure.
 */
extern void *bulk_alloc(size_t size);

/*
 * This function is also defined in bulk.c, and it frees an allocation
 * created with bulk_alloc().  Note that the pointer passed to this
 * function MUST have been returned by bulk_alloc(), and the size MUST
 * be the same as the size passed to bulk_alloc() when that memory was
 * allocated.  Any other usage is likely to fail, and may crash your
 * program.
 */
extern void bulk_free(void *ptr, size_t size);

/*
 * This function computes the log base 2 of the allocation block size
 * for a given allocation.  To find the allocation block size from the
 * result of this function, use 1 << block_size(x).
 *
 * Note that its results are NOT meaningful for any
 * size > 4088!
 *
 * You do NOT need to understand how this function works.  If you are
 * curious, see the gcc info page and search for __builtin_clz; it
 * basically counts the number of leading binary zeroes in the value
 * passed as its argument.
 */
static inline __attribute__((unused)) int block_index(size_t x) {
    if (x <= 8) {
        return 5;
    } else {
        return 32 - __builtin_clz((unsigned int)x + 7);
    }
}

/*
 * You must implement malloc().  Your implementation of malloc() must be
 * the multi-pool allocator described in the project handout.
 */
size_t powy(size_t x){
    size_t ret=1;
    for(size_t z=0;z<x;z++){
        ret=ret*2;
    }
    return ret;
}

bool freelist_validate(){
    for(size_t x=5;x<13;x++){
        if(freelist [x] != NULL){
            size_t temp =powy(x);
            fprintf(stderr,"Head of x %p %lu",freelist[x],x);
            if (freelist [x]->header != temp){
                fprintf(stderr,"\n in validator: ");
                fprintf(stderr,"\n x is%lu",x);
                fprintf(stderr,"\n header doesnt equal size");
                fprintf(stderr," \n header is :%lu",freelist[x]->header);
                fprintf(stderr," \n expected is:%lu",temp);
                return false;
            }
        }
        if(freelist [x] != NULL){
            for(struct node* h = freelist [x];h!=NULL;h=h->next){
                size_t temp=powy(x);
                if(h->header != temp){
                   return false;
               }
            }
        }
    }
    return true;
}

void *malloc(size_t size) {
    if(size==0){
        return NULL;
    }
    if(size>4088){
        //bulk alloc
        size_t realsize = size+8;
        void* ptr_ret = bulk_alloc(realsize);
        *(size_t*)ptr_ret = size;
        ptr_ret += sizeof(size_t);
        return ptr_ret;
    }
    size_t index=block_index(size);
    if(freelist==NULL){
        freelist=sbrk(CHUNK_SIZE);
        for(int x=0;x<13;x++){
            freelist[x]=NULL;
        }
    }
    void* point=freelist[index];
    size_t SIZE=powy(index);
    if(freelist[index]==NULL){
        freelist[index]=sbrk(CHUNK_SIZE);
        point=freelist[index];
        struct node* temp=freelist[index];
        temp->header=SIZE;
        freelist[index]=temp;
        point+=SIZE;
        size_t loopc=4096/SIZE;
        loopc=loopc-1;
        for(size_t x=0;x<loopc;x++){
            struct node* temp2=point;
            temp2->header=SIZE;
            point=temp2;
            temp2->next=freelist[index];
            freelist[index]=temp2;
            point+=SIZE;
        }
    }
    void* point_ret=freelist[index];
    freelist[index]->header=SIZE+1;
    point_ret+=sizeof(size_t);
    struct node* temp3=freelist[index];
    freelist[index]=freelist[index]->next;
    temp3->next=NULL;
    return point_ret;
}


/*
 * You must also implement calloc().  It should create allocations
 * compatible with those created by malloc().  In particular, any
 * allocations of a total size <= 4088 bytes must be pool allocated,
 * while larger allocations must use the bulk allocator.
 *
 * calloc() (see man 3 calloc) returns a cleared allocation large enough
 * to hold nmemb elements of size size.  It is cleared by setting every
 * byte of the allocation to 0.  You should use the function memset()
 * for this (see man 3 memset).
 */
void *calloc(size_t nmemb, size_t size) {
    if(nmemb * size== 0){
        return NULL;
    }
    void *ptr=malloc(nmemb * size);
    ptr-=sizeof(size_t);
    size_t temp=*(size_t*)ptr^1;
    ptr+=sizeof(size_t);
    memset(ptr,0,temp-8);
    return ptr;
}

/*
 * You must also implement realloc().  It should create allocations
 * compatible with those created by malloc(), honoring the pool
 * alocation and bulk allocation rules.  It must move data from the
 * previously-allocated block to the newly-allocated block if it cannot
 * resize the given block directly.  See man 3 realloc for more
 * information on what this means.
 *
 * It is not possible to implement realloc() using bulk_alloc() without
 * additional metadata, so the given code is NOT a working
 * implementation!
 */
void *realloc(void *ptr, size_t size) {
    if(ptr==NULL){
        void * ptr2=malloc(size);
        return ptr2;
    }
    if(size==0 && ptr!=NULL){
        free(ptr);
        return NULL;
    }
    ptr-=sizeof(size_t);
    size_t temp=*(size_t*)ptr;
    ptr+=sizeof(size_t);
    if(size>temp){
        void* ptr2=malloc(size);
        memcpy(ptr2,ptr,temp);
        free(ptr);
        return ptr2;
    }
    else{
        return ptr;
    }
    return NULL;
}

/*
 * You should implement a free() that can successfully free a region of
 * memory allocated by any of the above allocation routines, whether it
 * is a pool- or bulk-allocated region.
 *
 * The given implementation does nothing.
 */
void free(void *ptr) {
    if(ptr==NULL){
        return;
    }
    ptr-=sizeof(size_t);
    size_t bit=1;
    size_t temp=*(size_t*)ptr^bit;
    *(size_t*)ptr=temp;
    int index=block_index(temp-8);
    if(temp>4096){
        bulk_free(ptr,temp);
        return;
    }
    struct node* tnode=ptr;
    tnode->header=temp;
    tnode->next=freelist[index];
    freelist[index]=tnode;
    return;
}
/*
bool freelist_validate(node** freelist1){
    for(int x=5;x<13;x++){
        if(freelist1[x] != NULL){
            size_t temp =powy(x);
            if (freelist1[x]->header != temp){
                return false;
            }
        }
        if(freelist1[x] != NULL){
            for(struct node* h = freelist1[x];h!=NULL;h=h->next){
                size_t temp=powy(x);
                if(h->header != temp){
                   return false;
               }
            }
        }
    }
    return true;
}
*/
