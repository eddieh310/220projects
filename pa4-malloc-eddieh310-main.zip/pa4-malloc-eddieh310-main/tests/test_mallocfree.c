#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

#define als 1500
int main(int argc, char *argv[])
{
    void* p=malloc(2000);
    void* p2=malloc(2000);
    free(p);
    //   free(p2);
    if(3==4){ 
        fprintf(stderr,"to be in use %p",p2);
    }
    return 0;
}
