#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <stdbool.h>


int main(int argc, char *argv[]){
    void* ptr=malloc(2000);
    void* ptr4=calloc(4,500);
    if(3==4){
        fprintf(stderr,"%p %p  ",ptr4,ptr);
    }
    //free(ptr4);
    //freelist_validate(freelist);
}
