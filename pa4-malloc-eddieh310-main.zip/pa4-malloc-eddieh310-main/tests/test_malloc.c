#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

#define ALLOC_SIZE 4000
int main(int argc, char *argv[])
{
    void *p1, *p2, *brk1, *p3, *p4,*p5,*p6,*p7;
    p1 = malloc(ALLOC_SIZE);
    brk1 = sbrk(0);
    p2 = malloc(ALLOC_SIZE);
    p3 = malloc(ALLOC_SIZE);
    p4 = malloc(ALLOC_SIZE);
    p5 = malloc(ALLOC_SIZE);
    p6 = malloc(ALLOC_SIZE);
    p7=malloc(0);
    if (brk1 == NULL) {
        fprintf(stderr, "sbrk() failed: %p %p\n", p1, p2);
        fprintf(stderr, "sbrk() failed: %p %p\n", p3, p4);
        fprintf(stderr, "sbrk() failed: %p %p %p\n", p5, p6,p7);
    }
    if (p7!=NULL){
        return 1;
    }
    if (brk1 == sbrk(0)) {
        return 1;
    } else {
        return 0;
    }
}
