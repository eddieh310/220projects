#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

#define als 900
int main(int argc, char *argv[])
{
    void *p1, *p2, *brk1, *p3, *p4,*p5,*p7;
    p1 = malloc(als);
    brk1 = sbrk(0);
    p2=malloc(als);
    p3=sbrk(0);
    p4=malloc(als);
    p5=sbrk(0);
    p7=malloc(0);
    if (brk1 == NULL) {
        fprintf(stderr, "sbrk() failed: %p %p\n", p1, p2);
        fprintf(stderr, "sbrk() failed: %p %p\n", p3, p4);
        fprintf(stderr, "sbrk() failed: %p %p\n", p5,p7);
    }
    if (p7 != NULL){
        return 1;
    }
    if(brk1 != p3){
        return 1;
    }
    if(p3 != p5){
        fprintf(stderr,"this one");
        return 1;
    }
    if (brk1 != sbrk(0)) {
        return 1;
    } else {
        return 0;
    }
}
