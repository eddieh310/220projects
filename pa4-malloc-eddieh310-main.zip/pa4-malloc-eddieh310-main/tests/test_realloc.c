#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

int main(int argc, char *argv[])
{
    void* p=malloc(40);
    void* p2=realloc(p,500);
    if(3 == 4){
        free(p2);
    }
    /*
    void* p3=realloc(p,38);
    void* p4=realloc(p,80);
    void* p5=realloc(p3,380);
    void* p6=realloc(p,45);
    void* p7=realloc(p,65);
    void* p8=realloc(p,115);
    if(3==4){
        free(p3);
        free(p4);
        free(p5);
        free(p6);
        free(p7);
        free(p8);
    }
    */
    return 0;
}
