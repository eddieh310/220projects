#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

int main(int argc, char *argv[]){
    void* p1=malloc(2000);
    //free(p1);
    void *p2=malloc(2000);
    //fprintf(stderr,"%p",p2);
    void *p3=malloc(2000);
    if(3==4){
        free(p1);
        free(p2);
        free(p3);
    }
    //fprintf(stderr,"%p",p3);
    void *p4=malloc(2000);
    if(3==4){
        free(p4);
    }
    /*
    //fprintf(stderr,"%p",p4);
    void *p5=malloc(2000);
    void *p6=malloc(2000);
    void *p7=malloc(2000);
    void *p8=malloc(2000);
    void *p9=malloc(2000);
    free(p2);
    free(p8);
    if(3==5){
        fprintf(stderr,"%p",p2);
        fprintf(stderr,"%p",p3);
        fprintf(stderr,"%p",p4);
        fprintf(stderr,"%p",p5);
        fprintf(stderr,"%p",p6);
        fprintf(stderr,"%p %p %p ",p7,p9,p1);
    }
    */ 
}
